/* Justin Ngo
Programming for engineers
9/29/2016
Homework 4: Problem 1 - encryption

Info: substitution cipher know as ROT13 (rotation 13)
this program only takes letters (upper/lower) no numbers
so I don't have to worry about it*/

#include <iostream>
#include <string> 


void encrpyt(char *str) {
	int i = 0;
	//determine the length of the character array. 
	/*while (*(str + i) != '\0') { // These two while loop are the same thing but 
		std::cout << *(str + i);   // only using one. I'm just keeping this here 
		i++;					   // to have a reference
	}*/
	while (*(str + i)) 
	{
		//std::cout << *(str + i); //just a debugging tool
		i++;
	}
	for (int j = 0; j < i; j++) 
	{
		char encrpyt_rot13;
		if (*(str + j) <= 90) //upper case
		{
			if ((*(str + j) + (char)13) > 90)
			{
				encrpyt_rot13 = ((*(str + j) + (char)13) - 90) + (char)64;
			}
			else 
			{
				encrpyt_rot13 = *(str + j) + (char)13;
			}
		}
		else //lower case
		{
			if ((*(str + j) + (char)13) > 122)
			{
				encrpyt_rot13 = ((*(str + j) + (char)13) - 122) + (char)96;
			}
			else
			{
				encrpyt_rot13 = *(str + j) + (char)13;
			}
		}
		std::cout << encrpyt_rot13;
	}
	std::cout << std::endl;
	//length = sizeof(*str); // this takes the length of an array but returns how much that data type took up
							 // so an int takes 4 so if its array of 5 then it returns 20 bytes
}

int main() {
	int number_of_cases;
	std::cin >> number_of_cases;

	for (int i = 0; i < number_of_cases; i++)
	{
		std::cout << "Case " << i << ":\n";
		std::string case_word;
		std::cin >> case_word;
		encrpyt(&case_word[0]); //can also do case_word.data() which does similar thing but there are DIFFERENCES
	}
	return 0;
}