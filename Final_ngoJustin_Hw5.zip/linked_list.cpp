/*Justin Ngo
Programming for Engineers: Homework 5
October 22, 2016
Linked List: (This is like a treasure hunt)
that basically has a number and a reference to the next number. 

input: number of cases
too long to write... see assignment
need to use REPL (Read, eval, print, loop) 
*/

#include <iostream>
#include <string>

struct Node {
	int num;
	Node *next;
};void print(Node* node) {
	while (node->next != NULL) {
		std::cout << node->num << ", ";
		node = node->next;
	}
	std::cout << node->num << std::endl;
}
//void delete_node(Node** node) {
//	Node *temp = *node;
//	while (*node) {
//		temp = *node;
//		*node = temp->next;
//		delete temp;
//	}
//	delete temp;
//}

int main() {
	int number_of_cases = 0;
	std::cin >> number_of_cases;
	for (int i = 0; i < number_of_cases; ++i) {
		std::cout << "Case " << i << ":\n";
		Node *first_node = NULL; //empty initialization

		std::string command;
		std::cin >> command;

		int index, input;
		while (command != "end") { //action loop

			if (command == "prepend") { //think like its "cutting inline" of the NULL
				Node *temp = new Node;
				std::cin >> input;
				temp->num = input;
				temp->next = first_node;
				first_node = temp;
				print(first_node);
			}

			if (command == "append") {
				Node *temp = new Node;
				Node *find_end = new Node;
				find_end = first_node;
				std::cin >> input;
				if (find_end == NULL) { // when its empty
					temp->num = input;
					temp->next = NULL;
					first_node = temp;
				}
				else {
					while (find_end->next != NULL) {
						find_end = find_end->next;
					}
					temp->num = input;
					temp->next = NULL;
					find_end->next = temp;
				}
				print(first_node);
			}

			if (command == "insert") {
				Node *temp = new Node;
				Node *insert_at = new Node;
				insert_at = first_node;
				std::cin >> index >> input;
				if (index == 0) { // basically prepend
					temp->num = input;
					temp->next = first_node;
					first_node = temp;
				}
				else if (first_node == NULL) { //append and break
					temp->num = input;
					temp->next = NULL;
					first_node = temp;
				}
				else {
					for (int j = 1; j < index; ++j) {
						if (insert_at->next == NULL) {
							break;
						}
						insert_at = insert_at->next;
					}
					temp->num = input;
					temp->next = insert_at->next;
					insert_at->next = temp;
				}
				print(first_node);
			}

			if (command == "remove") {
				Node* temp = new Node;
				Node* remove = new Node;
				temp = first_node;
				remove = temp;
				std::cin >> index;
				if (index == 0) {
					temp = temp->next;
					remove->next = temp->next;
					delete temp;
					if (remove->next == NULL) {
						std::cout << "empty" << std::endl;
						break;
					}
					else {
						print(first_node);
					}
				}
				if (first_node == NULL) {
					std::cout << "empty" << std::endl;
				}
				else {
					for (int j = 0; j < index; ++j) {
						remove = temp;
						temp = temp->next;
						if (temp->next == NULL) {
							std::cout << "empty" << std::endl;
							break;
						}
					}
					remove->next = temp->next;
					delete temp;
					print(first_node);
				}
			}
			std::cin >> command;
		}

		if (first_node == NULL) {
			std::cout << "empty" << std::endl;
		}
		else {
			print(first_node);
		}
		//delete everything
		delete[] first_node;

	}
	return 0;
}