/*Justin Ngo
September 16, 2016
ME EN 5250: Programming for Engineers
Homework 3: Problem 1 - finding minimum and maximum of a list of numbers

Info: reads some number of integers and then finds the 
	maximum and minum in that list. 

	inputs will be
	first - number of cases
		then
	-how many numbers in list
	-then numbers in that list
	then repeat. */

#include <iostream>
#include <cmath>
#include <vector>

int main() {
	int number_of_cases;
	std::cin >> number_of_cases;

	for (int i = 0; i < number_of_cases;i++) {
		std::cout << "Case " << i << ":\n";
		int vector_length;
		std::cin >> vector_length;
		std::vector <int>list_of_numbers(vector_length);

		for (int j = 0; j < vector_length; j++) {
			std::cin >> list_of_numbers[j];
		}

		int max = list_of_numbers[0];
		int min = max;

		for (int k = 0; k < vector_length; k++) {
			if (max < list_of_numbers[k]) {
				max = list_of_numbers[k];
			} 
			if (min > list_of_numbers[k]) {
				min = list_of_numbers[k];
			}
		}
		std::cout << "Min: " << min << std::endl;
		std::cout << "Max: " << max << std::endl;

	}// end for loop case calculations


	return 0;
}//end main