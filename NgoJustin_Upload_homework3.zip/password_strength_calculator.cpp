/*Justin Ngo
September 16, 2016
ME EN 5250: Programming for Engineers
Homework 3: Problem 2 - analyzing strings (password) and rating them

Info: program takes a password ( a sring of characters without spaces)
and then rates it. needs to have a separate function called by the main.*/




#include <iostream>
#include <cctype>
#include <string>

int calculate_password_score(int password_length, std::string password) {
	int score = 0;
	int cases_sastisfied = 0;
	bool upper_case = false;
	bool lower_case = false;
	bool digits = false;
	bool punctations = false;
	score = password_length;

	for (int j = 0; j < password_length; j++) {
		if (std::isupper(password[j])) {
			upper_case = true;
		}
		else if (std::islower(password[j])) {
			lower_case = true;
		}
		else if (std::isdigit(password[j])) {
			digits = true;
		}
		else if (std::ispunct(password[j])) {
			punctations = true;
		}
	} // end determining what password has.
		  /*note to self: if your gonna use end if, it will only trigger
		  when the previous if statement proves to be false otherwise
		  the program will skip the rest of the statement if the previous
		  was found to be true.*/

	if (upper_case == true) {
		score = score + 1;
	}
	if (lower_case == true) {
		score = score + 1;
	}
	if (digits == true) {
		score = score + 1;
	}
	if (punctations == true) {
		score = score + 2;
	}
	cases_sastisfied = upper_case + lower_case + digits + punctations;
	if (cases_sastisfied > 1) {
		score = (int)pow(2, cases_sastisfied - 1) * score;
	}
	return score;
}//end function calculate_password_score



int main() {
	int number_of_cases;
	std::cin >> number_of_cases;

	for (int i = 0; i < number_of_cases; i++) {
		std::cout << "Case " << i << ':' << std::endl;
		std::string password;
		std::cin >> password;
		int password_length = password.size();
		std::cout << "Strength: " << calculate_password_score(password_length, password) << std::endl;
	}
	return 0;
}//end main