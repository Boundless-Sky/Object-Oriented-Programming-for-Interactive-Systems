#pragma once
#include <iostream>
#include <limits>
#include <algorithm>
#include <random>
#include "statistic.h"

class Min : public Statistic {
	double min;

public:
	Min();
	void accumulate(double x) override;
	void postprocess() override;
	double result() const override;
	void print(std::ostream &os) const override;
};
