#include "max_stat.h"
#include <iostream>
#include <limits>
#include <algorithm>
#include <random>


Max::Max() {
	max = -std::numeric_limits<double>::infinity();
}
void Max::accumulate(double x) {
	max = std::max(max, x);
}
void Max::postprocess() {
	// Nothing to do
}
double Max::result() const {
	return max;
}
void Max::print(std::ostream &os) const {
	os << "Max = " << max;
}
