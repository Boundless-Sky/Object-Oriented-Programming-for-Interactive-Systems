/*Justin Ngo
September 16, 2016
ME EN 5250: Programming for Engineers
Homework 3: Problem 3 - Reverse an integer using functions

Info: takes an int and reverse it. Can be any data type that is inputted
but only psotive ints are valid. For any other data type it is invalid
and program should not crash. */

#include <iostream>
#include <cmath>
#include <limits> //needed for std::numeric_limits

int reverse_number(int number) {
	int reverse_the_number = 0;
	int temp_number = number;
	/*if (number == 0) {
		return 0;
	}*/
	while (number != 0) {
		temp_number = number % 10;
		number = number / 10; //this is int division, which truncates
		reverse_the_number = reverse_the_number * 10 + temp_number;
	}
	return reverse_the_number;
}// end reverse_number function

int main() {
	int number_of_cases;
	std::cin >> number_of_cases;

	for (int i = 0; i < number_of_cases; i++) {
		std::cout << "Case " << i << ':' << std::endl;
		int number = 0;
		std::cin >> number;
		if ((number <= 0) || std::cin.fail()) {
			std::cout << "Invalid input\n";
			std::cin.clear();
			std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
			continue;
		}
		std::cout << reverse_number(number) << std::endl;
	}

	return 0;
}// end main
