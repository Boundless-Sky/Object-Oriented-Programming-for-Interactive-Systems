/*Justin Ngo
ME EN 5250: Programming for Engineers
Homework 6 - Linked list (continuation from Homework 5)
Now ordering it into classes
*/

#include <iostream>
#include <string>
class List {
private:
	struct Node {
		int val;
		Node* next;
	};
	//reminder to self: Node is not a member of List so you need to 
	//create a member object of type List::Node in class List
	//Could use (typedef Node* nodeptr) so you don't need to type Node* everytime
	Node* current;
public:
	List();
	void prepend(const int data);
	void append(const int data);
	void insert(const int location, const int data);
	void remove(const int location);
	void print();
	void release();
	//Rule of Three
	~List(); // Destructor
	List& operator=(const List& rhs); // Copy Assignment operator
	List(const List& rhs); //Copy Constructor


	friend std::ostream& operator<<(std::ostream& os, const List& a) {
		if (!a.current) {
			os << "empty";
		}
		else {
			Node* n = new Node;
			n = a.current;
			for (; n != nullptr; n = n->next) {
				os << n->val;
				if (n->next) {
					os << ", ";
				}
			}
		}
		return os;
	}
};


List::List(){
	current = nullptr;
};

void List::prepend(const int data) {
	Node* newNode = new Node;
	newNode->val = data;
	newNode->next = current;
	current = newNode;
}

void List::append(const int data) {
	Node* iterateNode = new Node;
	Node* newNode = new Node;

	iterateNode = current;

	if (!iterateNode) {
		newNode->next = current;
		newNode->val = data;
		current = newNode;
	}
	else {
		for (; iterateNode->next != nullptr; iterateNode = iterateNode->next);

		newNode->next = nullptr;
		newNode->val = data;

		iterateNode->next = newNode;
	}
}

void List::insert(const int location, const int data) {
	Node* newNode = new Node;
	if (!current) {
		newNode->val = data;
		newNode->next = current;
		current = newNode;
	}
	else {
		Node* temporary = nullptr;
		Node* iterateNode = new Node;
		iterateNode = current;
		for (int j = 0; j < location && iterateNode != nullptr; ++j) {
			temporary = iterateNode;
			iterateNode = iterateNode->next;
		}
		if (temporary) {
			newNode->val = data;
			newNode->next = iterateNode;
			temporary->next = newNode;
		}
		else {
			newNode->val = data;
			newNode->next = current;
			current = newNode;
		}
	}
	
}

void List::remove(const int location) {
	Node* newNode = new Node;
	if (!current) {	}
	else {
		if (location == 0) {
			newNode = current->next;
			delete current; //this deletes only the head
			current = newNode;
		}
		else {
			Node* temporary = nullptr;
			Node* iterateNode = new Node;
			iterateNode = current;
			//for (int j = 0; j < location && iterateNode->next != nullptr; ++j) { //deletes last place if location is outof bounds
			for (int j = 0; j < location && iterateNode != nullptr; ++j) {
				temporary = iterateNode;
				iterateNode = iterateNode->next;
			}
			if (iterateNode) {
				temporary->next = iterateNode->next;
				delete iterateNode;
			}
		}
	}
}

List::~List() {
	release();
}

void List::release() {
	if (!current) {}
	else {
		for (Node* newNode = current; newNode != nullptr;) {
			Node *next = newNode->next;
			delete newNode;
			newNode = next;
		}
	}
}

List& List::operator=(const List& rhs) {
	/* wiki - why do I need to do this?
	When deep copies of objects have to be made, exception safety should be taken into consideration. One way to achieve this when resource deallocation never fails is:
		Acquire new resources
		Release old resources
		Assign the new resources' handles to the object
	*/
	// stop self assignment i.e: z = z;
	this->current = nullptr;
	if (!&rhs.current) {
		current = nullptr;
	}
	else {
		if (&rhs != this) {
			Node* iterateNode = rhs.current;
			Node* temporary = nullptr;
			for (; iterateNode != nullptr; iterateNode = iterateNode->next) {
				Node* newNode = new Node; //bug here?
				newNode->val = iterateNode->val;
				newNode->next = nullptr;
				if (temporary == nullptr) {
					current = newNode;
					temporary = newNode;
				}
				else {
					temporary->next = newNode;
					temporary = newNode;
				}
			}
		}
		else {};
	}

	return *this;
}

List::List(const List& rhs) {
	/*
	implement an appropriate copy assignment operator. 
	Without this, the default-generated one will be used, 
	which simply copies all members. 
	That would result in a shallow copy only - 
	both the newly constructed stack object and the original copyStack 
	would point to the same nodes inside their LinkedList -
	probably not what you want. -"stackoverflow"
	*/
	this->current = nullptr;
	if (!&rhs.current) {
		current = nullptr;
	}
	else {
		Node* iterateNode = rhs.current;
		Node* temporary = nullptr;
		for (; iterateNode != nullptr; iterateNode = iterateNode->next) {
			Node* newNode = new Node;
			newNode->val = iterateNode->val;
			newNode->next = nullptr;
			if (temporary == nullptr) {
				current = newNode;
				temporary = newNode;
			}
			else {
				temporary->next = newNode;
				temporary = newNode;
			}
		}
	}
	
}

void List::print() {
	if (!current) {
		std::cout << "empty\n";
	}
	else {
		for (Node *n = current; n != nullptr; n = n->next) {
			std::cout << n->val;
			if (n->next) {
				std::cout << ", ";
			}
		}
		std::cout << "\n";
	}
}


void test_function(const List &current) {//current shouldn't change at all!!
	std::cout << "---- Test Function ----\n";
	List *b = new List(current);
	std::cout << "current = " 
		<< current << "\n"
		<< "b = " << *b << "\n";
	b->prepend(15);
	b->prepend(60);
	b->append(2);
	std::cout << "current = " << current << "\n"
		<< "b = " << *b << "\n";
	b->remove(1);
	std::cout << "current = " << current << "\n"
		<< "b = " << *b << "\n";
	List c;
	c.append(5);
	c.prepend(2);
	std::cout << "current = " << current << "\n"
		<< "b = " << *b << "\n"
		<< "c = " << c << "\n";
	c = *b; 
	b->append(100);
	c.insert(1, 4);
	std::cout << "current = " << current << "\n"
		<< "b = " << *b << "\n"
		<< "c = " << c << "\n";
	delete b;
	std::cout << "current = " << current << "\n"
		<< "c = " << c << "\n";
	std::cout << "---- End Test Function ----\n";
}

int main() {
	int num_cases = 0;
	std::cin >> num_cases;
	for (int i = 0; i < num_cases; ++i) {
		std::cout << "Case " << i << ":\n";
		std::string cmd;
		////calls copy assignment operator
		//List b;
		//b.prepend(2);
		//b.prepend(5);
		//List c;
		//c = b;
		//c.print();
		////calls copy constructor operator
		//List d(c);
		//d.print();

		List linked_list;
		while (cmd != "end") {
			std::cin >> cmd;
			if (cmd == "prepend") {
				int val = 0;
				std::cin >> val;
				linked_list.prepend(val);
			}
			else if (cmd == "append") {
				int val = 0;
				std::cin >> val;
				linked_list.append(val);
			}
			else if (cmd == "insert") {
				int val = 0, index = 0;
				std::cin >> index >> val;
				linked_list.insert(index, val);
			}
			else if (cmd == "remove") {
				int index = 0;
				std::cin >> index;
				linked_list.remove(index);
			}
			else if (cmd == "test") {
				test_function(linked_list);
			}
			linked_list.print();
		}
		//linked_list.print();
		//linked_list.release();//might be calling the destructor twice causing it to do undefined behaviour
	}
	return 0;
}