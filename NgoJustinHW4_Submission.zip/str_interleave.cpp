/* Justin Ngo
Programming for engineers
9/29/2016
Homework 4: Problem 2 - string interleave

Info: takes two strings from user and interleave them
1: two strings from user
2: then put into function that returns char pointer*/

#include <iostream>
#include <cstring>
#include <string>

char* strinterleave(const char *a, const char *b) {
	int length_a = (int)std::strlen(a);
	int length_b = (int)std::strlen(b);
	int total_length = length_a + length_b;
	char* interleave = new char[total_length+1]; //note to self: needed this since i need to add a null terminator later which will
												 //make the array longer then you intialized. If you don't have this and then try to delete[]. 
												 //It will cause an undefined behaviour which while cause an fail sound during debug runtime. 
	
	int k = 0;									 
	int l = 1;	
	//for unequal length 
	if (length_a > length_b) {
		for (int i = 0; i < length_b; i++) {
			interleave[k] = a[i];
			interleave[l] = b[i];
			k = k + 2;
			l = l + 2;
		}
		for (int i = length_b; i < length_a; i++) {
			interleave[k] = a[i];
			k = k + 1;
		}
	}
	else if (length_b > length_a) {
		for (int i = 0; i < length_a; i++) {
			interleave[k] = a[i];
			interleave[l] = b[i];
			k = k + 2;
			l = l + 2;
		}
		for (int i = length_a; i < length_b; i++) {
			interleave[k] = b[i];
			k = k + 1;
		}
	}
	else {//for equal length
		for (int i = 0; i < length_a; i++) {
			interleave[k] = a[i];
			interleave[l] = b[i];
			k = k + 2;
			l = l + 2;
		}
	}
	interleave[total_length] = '\0'; //null terminator
	return interleave;
}

int main() {
	int number_of_cases;
	std::cin >> number_of_cases;
	for (int i = 0; i < number_of_cases; i++) {
		std::cout << "Case " << i << ":\n";
		std::string a, b;
		std::cin >> a >> b;
		char* processed_word = strinterleave(a.data(),b.data());
		std::cout << processed_word << std::endl;
		delete[] processed_word;
	}
	return 0;
}
