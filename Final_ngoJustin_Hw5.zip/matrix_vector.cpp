/*Justin Ngo
Programming for Engineers: Homework 5
October 22, 2016
Matrix Vector: so times a matrix to a vector so like (3X3)*(3X1) = (3x1)

input: number of cases
a string on what to do. ( dot, length, transpose, row, col multiply)
M (for matrix) followed by 9 numbers
V (for vector) followed by 3 numbers
*/

#include <iostream>
#include <string>

struct Vec3 {
	double x, y, z;
};

struct Mat3 {
	double a1, a2, a3, b1, b2, b3, c1, c2, c3;
};

Vec3 read_vec() /*read three doubles from the standard input, use them
to construct a Vec3 and return it.You can assume the three doubles will
be given in the standard input as three numbers separated by spaces.*/
{
	Vec3 v3;
	std::cin >> v3.x >> v3.y >> v3.z;
	return v3;
}

Mat3 read_mat() /*read nine doubles from the standard input, use them
to construct a Mat3 and return it.We use the row - major ordering for the
nine numbers.That is, the first three numbers make up the first row of
the matrix, the next three make up the second row, and so on.*/
{
	Mat3 m3;
	std::cin >> m3.a1 >> m3.a2 >> m3.a3 
			 >> m3.b1 >> m3.b2 >> m3.b3 
			 >> m3.c1 >> m3.c2 >> m3.c3;
	return m3;
}

void print(Vec3 v)/* print the given vector to the standard output.The
format is(x, y, z).*/
{
	std::cout << "( " << v.x << ", " << v.y << ", " << v.z << " )";
	std::cout << std::endl;
}

void print(Mat3 m) /*print the given matrix to the standard output.
The format is[a, b, c, d, e, f, g, h, i].The elements are in
row - major ordering(see above for what this means).*/
{
	std::cout << "[ " << m.a1 << ", " << m.a2 << ", " << m.a3 << ", "
			          << m.b1 << ", " << m.b2 << ", " << m.b3 << ", "
		              << m.c1 << ", " << m.c2 << ", " << m.c3 << " ]";
	std::cout << std::endl;
}
Vec3 add(Vec3 u, Vec3 v)  /*add two vectors and return the result.*/
{
	return Vec3{ u.x + v.x, u.y + v.y, u.z + v.z };
	//need curly braces becuase we did not declare a variable before per say. I.e Vec3 add;.
	//the curly braces are an "initiliazation" of the newly created Vec3 type. 
}

double dot(Vec3 u, Vec3 v)  /*return the dot product of two vectors.*/
{
	return ( (u.x * v.x) + (u.y * v.y) + (u.z * v.z) );
}

 double length(Vec3 u) /*return the length(or magnitude) of the input
vector.*/
{
	return sqrt( (u.x * u.x) + (u.y * u.y) + (u.z * u.z) );
}

 Mat3 transpose(Mat3 m) /* return the transpose of the given matrix*/
{
	 return Mat3{ m.a1, m.b1 ,m.c1, m.a2, m.b2, m.c2, m.a3, m.b3, m.c3 };
}

 Vec3 row(Mat3 m, int i) /* return the i - th row of the given matrix(indexing
	 starts from 0)*/
{
	 Vec3 ith_row{};
	 if (i == 0) { ith_row = { m.a1, m.a2, m.a3 }; }
	 if (i == 1) { ith_row = { m.b1, m.b2, m.b3 }; }
	 if (i == 2) { ith_row = { m.c1, m.c2, m.c3 }; }
	 return ith_row;
}

 Vec3 col(Mat3 m, int i) /* return the i - th column of the given matrix
	 (indexing starts from 0)*/
{
	 Vec3 ith_col{};
	 if (i == 0) { ith_col = { m.a1, m.b1, m.c1 }; }
	 if (i == 1) { ith_col = { m.a2, m.b2, m.c2 }; }
	 if (i == 2) { ith_col = { m.a3, m.b3, m.c3 }; }
	 return ith_col;
}

 Vec3 multiply(Mat3 m, Vec3 u)  /*multiply a matrix with a vector and
	 return the resulting vector.*/{	 return Vec3{ (m.a1*u.x + m.a2*u.y + m.a3*u.z), (m.b1*u.x + m.b2*u.y + m.b3*u.z),				  (m.c1*u.x + m.c2*u.y + m.c3*u.z) };} Mat3 multiply(Mat3 m1, Mat3 m2) /* multiply two matrices(in the order
		 given) and return the resulting matrix.*/
{
	 return Mat3{ (m1.a1*m2.a1 + m1.a2*m2.b1 + m1.a3*m2.c1), (m1.a1*m2.a2 + m1.a2*m2.b2 + m1.a3*m2.c2), (m1.a1*m2.a3 + m1.a2*m2.b3 + m1.a3*m2.c3), 
				  (m1.b1*m2.a1 + m1.b2*m2.b1 + m1.b3*m2.c1), (m1.b1*m2.a2 + m1.b2*m2.b2 + m1.b3*m2.c2), (m1.b1*m2.a3 + m1.b2*m2.b3 + m1.b3*m2.c3), 
				  (m1.c1*m2.a1 + m1.c2*m2.b1 + m1.c3*m2.c1), (m1.c1*m2.a2 + m1.c2*m2.b2 + m1.c3*m2.c2), (m1.c1*m2.a3 + m1.c2*m2.b3 + m1.c3*m2.c3) };
}

int main() {
	int number_of_inputs = 0;
	std::cin >> number_of_inputs;
	for (int j = 0; j < number_of_inputs; j++) {
		std::cout << "Case " << j << ":\n";
		std::string operation_type, input_type; //V is vector (3x1), M is matrix (3x3)
		std::cin >> operation_type;
		if (operation_type == "length") {
			Vec3 v{}; Mat3 m{};
			std::cin >> input_type; 
			if (input_type == "V") { v = read_vec(); }
			else if (input_type == "M") { m = read_mat(); };
			std::cout << length(v) << std::endl; 
		}
		if (operation_type == "transpose") { 
			Vec3 v{}; Mat3 m{};
			std::cin >> input_type; 
			if (input_type == "V") { v = read_vec(); }
			else if (input_type == "M") { m = read_mat(); };
			print(transpose(m)); 
		}
		if (operation_type == "row") {
			Vec3 v{}; Mat3 m{}; int i;
			std::cin >> input_type;
			if (input_type == "V") { v = read_vec(); }
			else if (input_type == "M") { m = read_mat(); };
			std::cin >> i;
			print(row(m, i));
		}
		if (operation_type == "col") {
			Vec3 v{}; Mat3 m{}; int i;
			std::cin >> input_type;
			if (input_type == "V") { v = read_vec(); }
			else if (input_type == "M") { m = read_mat(); };
			std::cin >> i;
			print(col(m, i));
		}
		//add, dot, multiply needs two inputs
		if (operation_type == "add") {
			Vec3 v{}, v2{}; Mat3 m{};
			std::cin >> input_type;
			if (input_type == "V") { v = read_vec(); }
			else if (input_type == "M") { m = read_mat(); };
			std::cin >> input_type;
			if (input_type == "V") { v2 = read_vec(); }
			else if (input_type == "M") { m = read_mat(); };
			print(add(v, v2));
		}
		if (operation_type == "dot") {
			Vec3 v{}, v2{}; Mat3 m{};
			std::cin >> input_type;
			if (input_type == "V") { v = read_vec(); }
			else if (input_type == "M") { m = read_mat(); };
			std::cin >> input_type;
			if (input_type == "V") { v2 = read_vec(); }
			else if (input_type == "M") { m = read_mat(); };
			std::cout << dot(v, v2) << std::endl;
		}
		if (operation_type == "multiply") {
			Vec3 v{}; Mat3 m{}, m2{}; int check = 0;
			std::cin >> input_type;
			if (input_type == "V") { v = read_vec(); check = 1; }
			else if (input_type == "M") { m = read_mat(); };
			std::cin >> input_type;
			if (input_type == "V") { v = read_vec(); check = 1; }
			else if (input_type == "M") { m2 = read_mat(); };
			if (check == 1) {
				print(multiply(m, v));
			}
			else {
				print(multiply(m, m2));
			}
		}
	}
	return 0;
}