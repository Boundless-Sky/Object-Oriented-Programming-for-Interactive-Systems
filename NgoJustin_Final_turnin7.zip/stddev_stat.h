#pragma once
#include "statistic.h"
#include <cmath>

class stddevs : public Statistic {
	int count;
	double dev;
	double avg;
	double avgsq;

public:
	stddevs();
	void accumulate(double x) override;
	void postprocess() override;
	double result() const override;
	void print(std::ostream &os) const override;
};
