#include "sum_stat.h"

sum_stat::sum_stat() : sum(0) {};

void sum_stat::accumulate(double x) {
	sum = sum + x;
}

void sum_stat::postprocess() {/*Nothing*/}

double sum_stat::result() const{
	return sum;
}

void sum_stat::print(std::ostream &os) const {
	os << "Sum = " << sum;
}

