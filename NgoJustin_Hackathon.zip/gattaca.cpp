/*
Justin Ngo: Hackathon - GATTACA
info: Write a program that reads in two DNA strands from the standard input, and
prints all the positions in the first strand (the base) at which the second strand
(the template) can attach itself to.
*/

#include <iostream>
#include <string>

bool determine_match(char base, char strand) {
	/*
	determine if the base is an A, G ,T ,C then look for the correspoinding match then continue if it is.
	*/
	if (base == 'A') { //Adenosine <-> Thymine
		if (strand == 'T') {
			return true;
		}
	}
	else if (base == 'T') { //Thymine <-> Adenosine
		if (strand == 'A') {
			return true;
		}
	}
	else if (base == 'G') {//Guanine <-> Cytosine
		if (strand == 'C') {
			return true;
		}
	}
	else if (base == 'C') {//Cytosine <->  Guanine 
		if (strand == 'G') {
			return true;
		}
	}
	return false;
}

int main() {
	int number_of_cases = 0;
	std::cin >> number_of_cases;
	for (int i = 0; i < number_of_cases; ++i) {
		std::cout << "Case " << i << ":\n";
		std::string base, strand;
		std::cin >> base >> strand;
		int bl = base.length();
		int sl = strand.length();
		int number_of_matches = 0;

		if (sl > bl) {
			std::cout << "None" << std::endl;
			continue;
		}

		for (int j = 0; j < bl; ++j) {
			int flag = 0;
			if (determine_match(base[j], strand.front())) {
				for (int k = 0; k < sl; ++k) {
					if (bl == sl) {
						if (determine_match(base[k], strand[k])) {
							++flag;
							continue;
						}
						else {
							break;
						}
					}
					else {
						if (determine_match(base[j + k], strand[k])) {
							++flag;
							continue;
						}
						else {
							break;
						}
					}
				}

				if (flag == sl) {
					if (number_of_matches == 0) {
						std::cout << j;
					}
					else {
						std::cout << " " << j;
					}
					++number_of_matches;
				}
			}
		}

		if (number_of_matches == 0) {
			std::cout << "None" << std::endl;
		}
		else {
			std::cout << std::endl;
		}
		
	}
	return 0;
}