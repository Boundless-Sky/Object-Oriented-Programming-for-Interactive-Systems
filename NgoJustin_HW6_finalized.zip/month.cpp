/*Justin Ngo
ME EN 5250: Programming for Engineers
Homework 6 - month
In this problem you will write a class called Month that encapsulates a calendar
month.
*/

#include <iostream>
#include <string>

class Month {
private:
	static const int num_days[12]; // 31, 28, 30, etc
	static const char* names[12]; // "Jan", "Feb", etc
	static const char* week_days[7]; // "Mon", "Tue", etc
	int month;
	int day;
public:
	//public declaration
	Month(const char* name, int fd); /*constructs a month with a threeletter
		name (one of �Jan�, �Feb�, �Mar�, . . . , �Dec�), and an integer (fd)
		from 1 to 7 indicating the first day of the first week of the month. A value
		of 1 for fd means Sunday, 2 means Monday, and so on until 7, which means
		Saturday*/
	Month(int m, int fd); /*constructs a month with an integer (m) from 1
		to 12 representing January to December respectively, and a second integer
		(fd) indicating the first day of the week of the month as above.*/

	const char* name() const; /* returns the three-letter name for the current
		Month object. For example, if the current object represents January, this
		function should return "Jan".
		*/

	Month next_month() const; /*returns a Month object representing the next
		month. Remember to calculate the first day of the first week of the next
		month correctly. We always consider February to have 28 days in this
		problem*/

	int get_first_day() const; /* returns the first day of the first week of
		the current Month object as an integer from 1 to 7 (representing Sunday
		to Saturday).*/

	void print(std::ostream& os); /* prints the current Month object to an
		output stream. If the month is January and the first day of the first week
		is Wednesday you should print Jan Wed.
		
		-----------Why do this way? ---- overstack

		The benefit of switching to the ostream version is that in the case you later need to print to other places besides std::cout then you can do it with the same function implementation, whereas in this moment if you want to print to a file you would need to use a different function.

		An example of how to implement it is instead of doing this:

		void print()
		{   
			std::cout << "Print something always to cout" << std::endl;
		}
		You do this (notice we are passing a reference):

		void print(std::ostream& os) 
		{   
			os << "Print something to wherever the caller wants to" << std::endl;
		}   
		Now instead of calling the function like:

		print();
		You will be calling the function like this to print to cout:

		print(std::cout);
		or like this to print to a file:

		std::ofstream some_file("test.txt");
		a.print(some_file);
		See, with the same function you can decide where you want the print to go.*/
};

//Private initialization
const int Month::num_days[12] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
const char* Month::names[12] = { "Jan", "Feb", "Mar", "Apr",
"May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
const char* Month::week_days[7] = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };

//Public method definition
Month::Month(const char* name, int fd) {
	int i = 0;
	for (; name != names[i]; ++i);
	month = i;
	day = fd - 1;
}

Month::Month(int m, int fd) {
	month = m - 1;
	day = fd - 1;
}

 const char* Month::name() const {
	 return names[month];
}

Month Month::next_month() const {
	int days_left = num_days[month];
	int next_first = get_first_day();

	days_left = days_left % 7;
	for (int j = 0; j < days_left; ++j) {
		++next_first;
		if (next_first >= 7) {
			next_first = 0;
		}
	}

	if (month == 11) {
		return Month{ "Jan" , next_first + 1 };
	}
	else {
		int nxt_month = month + 2; //need to offset by two since the object 'Month' creation minuses by one to get the correct array value
		return Month( nxt_month, next_first + 1 );
	}
	
 }

int Month::get_first_day() const {
	return day;
}

void Month::print(std::ostream& os) {
	//os << names[month] << " " << week_days[day];
	os << this->name() << " " << week_days[this->get_first_day()];
}

int main() {
	int number_of_cases = 0;
	std::cin >> number_of_cases;
	for (int i = 0; i < number_of_cases; ++i) {
		std::cout << "Case " << i << ":\n";
		int month, first_day, months_after;
		std::cin >> month >> first_day >> months_after;
		Month current(month, first_day);
		if (months_after == 1) {
			current.print(std::cout);
			std::cout << std::endl;
		}
		else {
			for (int j = 0; j < months_after -1 ; ++j) {
				current.print(std::cout);
				current = current.next_month();
				std::cout << ", ";
			}
			current.print(std::cout);
			std::cout << std::endl;
		}
	}
	return 0;
}
