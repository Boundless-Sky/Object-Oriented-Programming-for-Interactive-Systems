/* Justin Ngo
Programming for engineers
9/29/2016
Homework 4: Problem 4 - Matrix Multiplication

Info: inputs n x m and m x p then it outputs n x p. 
inputs should be in row-major order. (row 0's elements then row 1)*/

#include <iostream>
#include <iomanip>

// Print an N x M matrix row by row with 1 row per line
void print_matrix(const double *mat, const int n, const int m) {
	// Loop over each row
	for (int i = 0; i < n; ++i) {
		// Loop over each column in the i'th row
		for (int j = 0; j < m; ++j) {
			// Element [i, j] index = row_num * num_cols + col_num
			std::cout << std::setw(8) << mat[i * m + j] << " ";
		}
		std::cout << "\n";
	}
}
double* read_matrix(int row, int col) {
	double* matrix = new double[row * col];
	for (int i = 0; i < row; i++) {
		for (int j = 0; j < col; j++) {
			std::cin >> matrix[i * col + j];
		}
	}
	return matrix;
}

double* multiply_matrix(const double* a, const double* b, int n, int m, int p ) {
	double* matrix = new double[n * p];
	double ans = 0;
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < p; j++) {
			for (int k = 0; k < m; k++) {
				ans = (a[i * m + k] * b[k * p + j]) + ans;
			}
			matrix[i * p + j] = ans;
			ans = 0;
		}
	}
	return matrix;
}

int main() {
	int number_of_cases;
	std::cin >> number_of_cases;
	for (int i = 0; i < number_of_cases; i++) {
		std::cout << "Case " << i << ":\n";
		int row, col, row2, col2;
		std::cin >> row >> col; // n x m
		double* matrix_a = read_matrix(row, col);
		std::cin >> row2 >> col2; // m x p
		double* matrix_b = read_matrix(row2, col2);
		double* resultant = multiply_matrix(matrix_a, matrix_b, row, col, col2);
		print_matrix(resultant, row, col2);
		delete[] matrix_a, matrix_b, resultant;
	}
	return 0;
}