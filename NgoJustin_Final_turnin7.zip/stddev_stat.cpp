#include "stddev_stat.h"

stddevs::stddevs() : count(0) , dev(0) , avg(0) , avgsq(0){}

void stddevs::accumulate(double x) {
	avg += x;
	avgsq += (x*x);
	++count;
}

void stddevs::postprocess() {
	if (count > 1) {
		avg /= count;
		avgsq /= count;
		dev = std::sqrt(count / (count - 1.0))*std::sqrt(avgsq - (avg*avg));
	}
	else {}
}
double stddevs::result() const {
	return dev;
}
void stddevs::print(std::ostream &os) const {
	if (count > 1) {
		os << "StdDev = " << dev;
	}
	else {
		os << "StdDev = nan";
	}
}