#pragma once

// MyArray is a basic fixed size dynamically allocated array
// of integers.
class MyArray {
	// Size of the array we've allocated
	size_t size;
	// Pointer to the array of ints being stored
	int *array;
public:
	// When our object is created it acquires a resource (in
	// this case memory) to put itself in a valid usable state.
	// It's valid usable state is an array of 'size' integers.
	MyArray(size_t sz);

	// When our object is destroyed it must also release the
	// resource (in this case memory) that it acquired.
	~MyArray();

	// Copy constructor must correctly copy an existing array's
	// contents into this new one
	MyArray(const MyArray &a);

	// Copy-assignment operator must release our previous memory
	// and get a copy of rhs's memory. We must also prevent
	// self-assignment since this would result in us deleting
	// and then trying to copy our own memory!
	MyArray& operator=(const MyArray &rhs);

	int& operator[](size_t i);

	// We must also provide a const accessor so we can index
	// into a const MyArray
	const int& operator[](size_t i) const;

	size_t get_size() const;
};

