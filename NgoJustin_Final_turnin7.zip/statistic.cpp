#include <iostream>
#include <limits>
#include <algorithm>
#include <random>
#include "statistic.h"


Statistic::~Statistic() {};

// We can define an output operator overload for a Statistic&
// and it will call the child's overloaded print method,
// allowing us to generically print objects.
std::ostream& operator<<(std::ostream &os, const Statistic &stat) {
	stat.print(os);
	return os;
}
