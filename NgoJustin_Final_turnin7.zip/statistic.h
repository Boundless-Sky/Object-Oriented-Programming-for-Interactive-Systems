#pragma once
#include <iostream>
#include <limits>
#include <algorithm>
#include <random>

// The statistic interface that provides methods to be overriden
// and implemented by the child statistics such as min or max.
class Statistic {
public:
	// We must provide a virtual destructor so that child
	// classes can override the destructor.
	virtual ~Statistic();

	// This method is called on each element of the list
	// passing it to the statistic so it can update its result
	virtual void accumulate(double x) = 0;

	// Called after the dataset has been traversed so stats can
	// do any final computation
	virtual void postprocess() = 0;

	// Called to return the result computed by the statistic
	virtual double result() const = 0;

	// Method for the child statistic to override so it can
	// print its result
	virtual void print(std::ostream &os) const = 0;
};

// We can define an output operator overload for a Statistic&
// and it will call the child's overloaded print method,
// allowing us to generically print objects.
std::ostream& operator<<(std::ostream &os, const Statistic &stat);
