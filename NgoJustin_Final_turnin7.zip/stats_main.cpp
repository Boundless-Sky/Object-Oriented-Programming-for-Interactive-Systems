#include <iostream>
#include <limits>
#include <algorithm>
#include <random>
#include <string>
#include "statistic.h"
#include "average_stat.h"
#include "max_stat.h"
#include "min_stat.h"
#include "sum_stat.h"
#include <vector>
#include "stddev_stat.h"

//inputs::
//number of cases
//-> how many statistic to look for
//--> statistic name(s)
//---> number of data points
//----> data points


int main() {
	int num_of_cases = 0;
	std::cin >> num_of_cases;
	for (int i = 0; i < num_of_cases; ++i) {
		std::cout << "Case " << i << ":\n";

		int num_of_stats = 0;
		std::cin >> num_of_stats;
		std::vector<std::string> stat_names;
		std::string snames;
		for (int j = 0; j < num_of_stats; ++j) {
			std::cin >> snames;
			stat_names.push_back(snames);
		}

		int num_of_datapts = 0;
		std::cin >> num_of_datapts;
		std::vector<double> datapts(num_of_datapts);
		std::vector<Statistic*> statistics;
		statistics.push_back(new Min{});
		statistics.push_back(new Max{});
		statistics.push_back(new Average{});
		statistics.push_back(new sum_stat{});
		statistics.push_back(new stddevs{});
		for (int k = 0; k < num_of_datapts; ++k) {
			std::cin >> datapts[k];
			for (size_t a = 0; a < statistics.size(); ++a) {
				statistics[a]->accumulate(datapts[k]);
			}
		}
		for (size_t c = 0; c < statistics.size(); ++c) {
			statistics[c]->postprocess();
		} 
		for (int l = 0; l < num_of_stats; ++l) {
			if (stat_names[l] == "min") { std::cout << *statistics[0] << "\n"; }
			if (stat_names[l] == "max") { std::cout << *statistics[1] << "\n"; }
			if (stat_names[l] == "average") { std::cout << *statistics[2] << "\n"; }
			if (stat_names[l] == "sum") { std::cout << *statistics[3] << "\n"; }
			if (stat_names[l] == "stddev") { std::cout << *statistics[4] << "\n"; }
		}
		for (size_t d = 0; d < statistics.size(); ++d) {
			delete statistics[d]; 
			statistics[d] = nullptr;
		}

		/*for (int l = 0; l < num_of_stats; ++l) {
			if (stat_names[l] == "min") {
				Min minz;
				for (int k = 0; k < num_of_datapts; ++k) {
					minz.accumulate(datapts[k]);
				}
				minz.postprocess();
				minz.print(std::cout);
				std::cout << std::endl;
			}
			if (stat_names[l] == "max") {
				Max maxz;
				for (int k = 0; k < num_of_datapts; ++k) {
					maxz.accumulate(datapts[k]);
				}
				maxz.postprocess();
				maxz.print(std::cout);
				std::cout << std::endl;
			}
			if (stat_names[l] == "average") {
				Average avgz;
				for (int k = 0; k < num_of_datapts; ++k) {
					avgz.accumulate(datapts[k]);
				}
				avgz.postprocess();
				avgz.print(std::cout);
				std::cout << std::endl;
			}
			if (stat_names[l] == "sum") {
				sum_stat sumz;
				for (int k = 0; k < num_of_datapts; ++k) {
					sumz.accumulate(datapts[k]);
				}
				sumz.postprocess();
				sumz.print(std::cout);
				std::cout << std::endl;
			}
			if (stat_names[l] == "stddev") {
				stddevs devz;
				for (int k = 0; k < num_of_datapts; ++k) {
					devz.accumulate(datapts[k]);
				}
				devz.postprocess();
				devz.print(std::cout);
				std::cout << std::endl;
			}
		}*/
		
	}
		return 0;
}
	
			
			

			


