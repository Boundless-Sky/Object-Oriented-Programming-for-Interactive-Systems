/*
Justin Ngo: Hackathon - N- D boxes
info: build a class for the manipulation of axis aligned
boxes in several dimensions.

RULE OF THREE: if you have one method in the rule of three (copy constrcutor, assignment operator, or destructor)
you need all three.

*/

#include <iostream>
#include <string>
#include <vector>
#include <assert.h>
#include <algorithm>


class range {
private:
	// Choose your way to store the information on a range.
	// Note that you need to be able to store an empty range
	// (a range with no min nor max).
	double min;
	double max;
	bool empty;
public:
	// Interface for the class. You need to properly implement
	// the following methods

	// Constructor: create an empty range
	// (carefully choose the representation for an empty range)
	// JN - return null?
	range() : min(0), max(0), empty(true) {};
	//range() : min(), max(), empty(true) {};

	// Constructor: range of a given size centered around 0
	range(double size) { min = -size; max = size; empty = false; };

	// Constructor from a given min and max (note that the range passed could be empty)
	range(double min, double max) : min(min), max(max), empty(false) { };

	// Copy constructor
	range(const range &a) { min = a.min; max = a.max; empty = a.empty; };

	~range() {}

	// Test if the range is empty
	// (depends on how you define an empty range)
	// JN - the method definition can be placed outside this class delcartion scope
	// like bool range::is_empty() const { return (insert stuff here); } or can just do it 
	// in the class declaration scope. 
	bool is_empty() const {
		if (empty || (min > max)) {
			return true;
		}
		else {
			return false;
		}
	}

	// Get the min of the range
	/* RIGHT HERE ON THE GET MIN() AND MAX() I COULD DECLARE IT OUTSIDE THE CLASS DELCARTION AS
	DOUBLE RANGE::GET_MIN() CONST {RETURN MIN;} AND LEFT THE CLASS DELCARATION AS DOUBLE GET_MIN() CONST {};*/
	double get_min() const { return min; }

	// Get the max of the range
	double get_max() const { return max; }

	// Assignment operator
	range& operator=(const range &rhs) {
		min = rhs.get_min();
		max = rhs.get_max();
		empty = rhs.empty;
		return *this;
	}

	// sending out operator " << "
	friend std::ostream &operator<<(std::ostream &outputstream, const range &rhs) {
		if (rhs.is_empty()) {
			outputstream << "( )";
			return outputstream;
		}
		else {
			outputstream << "(" << rhs.get_min() << ", " << rhs.get_max() << ")";
			return outputstream;
		}
	}

	// Normalized union of ranges (normalization fills
	// a possible gap in the range)
	range operator+(const range &rhs) const {
		double minimum, maximum;
		if (rhs.is_empty() && (min > max)) {
			return range();
		}
		else if (rhs.is_empty()) {
			return range{ min, max };
		}
		else if (min > max) {
			return range{ rhs.get_min(), rhs.get_max() };
		}
		else {
			if (min < rhs.get_min()) {
				minimum = min;
			}
			else {
				minimum = rhs.get_min();
			}
			if (max > rhs.get_max()) {
				maximum = max;
			}
			else {
				maximum = rhs.get_max();
			}
			return range{ minimum, maximum };
		}
	}

	// Normalized intersection of ranges (normalization fills
	// a possible gap in the range)
	range operator&(const range &rhs) const {
		double minimum, maximum;
		if (rhs.is_empty()) {
			return range();
		}
		else if (rhs.get_max() < rhs.get_min()) { // max must be greater than min or results in empty. 
			return range();
		}
		else if ((min >= rhs.get_min() && min <= rhs.get_max()) ||
			(max >= rhs.get_min() && max <= rhs.get_max()) ||
			(rhs.get_min() >= min && rhs.get_min() <= max) ||
			(rhs.get_max() >= min && rhs.get_max() <= max)) {
			//find the max of the minimums
			if (min < rhs.get_min()) {
				minimum = rhs.get_min();
			}
			else {
				minimum = min;
			}

			//find the min of the maximums
			if (max > rhs.get_max()) {
				maximum = rhs.get_max();
			}
			else {
				maximum = max;
			}
			return range{ minimum, maximum };
		}
		else {
			return range();
		}
	}
};

class nd_box {
private:
	int dim = 0;
	range* dims = nullptr;
public:
	// Create an empty box
	nd_box() : dim(), dims() {};

	// Copy constructor
	nd_box(const nd_box &a) : dim(a.dim), dims(a.dims) {};

	// Constructor for 1D ranges
	nd_box(const range &a) { dim = 1; dims = new range[dim]; dims[dim - 1] = a; };

	// Constructor for rectangles
	nd_box(const range &a, const range &b) {
		dim = 2;
		dims = new range[dim];
		dims[dim - 1] = b;
		dims[dim - 2] = a;
	};

	// Constructor for 3D rectangular boxes
	nd_box(const range &a, const range &b, const range &c) {
		dim = 3;
		dims = new range[dim];
		dims[dim - 1] = c;
		dims[dim - 2] = b;
		dims[dim - 3] = a;
	};

	// Constructor for 4D boxes
	nd_box(const range &a, const range &b, const range &c,
		const range &d) {
		dim = 4;
		dims = new range[dim];
		dims[dim - 1] = d;
		dims[dim - 2] = c;
		dims[dim - 3] = b;
		dims[dim - 4] = a;
	};

	// Destructor, should free the ranges you've allocated
	~nd_box() { delete[] dims; };

	// sending out operator " << "
	friend std::ostream &operator<<(std::ostream &outputstream, const nd_box &rhs) {
		if (rhs.is_empty()) {
			outputstream << "[ ]";
			return outputstream;
		}
		else {
			for (int i = 0; i < rhs.get_dim(); ++i) {
				if (rhs.dims[i].is_empty()) {
					return outputstream << "[ ]";
				}
			}
			for (int i = 0; i < rhs.get_dim(); ++i) {
				if (i == 0) {
					outputstream << "[";
					outputstream << rhs.dims[i];
				}
				else {
					outputstream << rhs.dims[i];
				}
			}
			outputstream << "]";
			return outputstream;
		}
	};

	bool is_empty() const {
		if (dim == 0) {
			return true;
		}
		else {
			return false;
		}
	};

	// Get the dimension of the range
	int get_dim() const { return dim; };

	// Assignment operator
	nd_box& operator=(const nd_box &rhs) {
		dim = rhs.get_dim();
		dims = rhs.dims;
		return *this;
	};

	// Normalized union of boxes
	nd_box operator+(const nd_box &rhs) const {
		if (rhs.is_empty()) {
			return nd_box();
		}
		else {
			assert(rhs.get_dim() == dim);
			//if (rhs.get_dim() == dim) {
			//	int flag = 0, flag2 = 0, flag3 = 0;
			//	// if one of the ranges that makes up the boxes is empty (max < min) then make it all empty
			//  // something is a miss with the given case 20. 
			//	for (int i = 0; i < dim; ++i) {
			//		if ((dims[i].is_empty() && rhs.dims[i].is_empty()) || flag > 0) {
			//			dims[i] = range();
			//			rhs.dims[i] = range();
			//			++flag;
			//		}
			//		else if (dims[i].is_empty() || flag2 > 0) {
			//			dims[i] = range();
			//			++flag2;
			//		}
			//		else if (rhs.dims[i].is_empty() || flag3 > 0) {
			//			rhs.dims[i] = range();
			//			++flag3;
			//		}
			//	}
			//}
			if (rhs.get_dim() == 1 && dim == 1) {
				return nd_box{ dims[0] + rhs.dims[0] };
			}
			else if (rhs.get_dim() == 2 && dim == 2) {
				return nd_box{ dims[0] + rhs.dims[0], dims[1] + rhs.dims[1] };
			}
			else if (rhs.get_dim() == 3 && dim == 3) {
				return nd_box{ dims[0] + rhs.dims[0], dims[1] + rhs.dims[1],
					dims[2] + rhs.dims[2] };
			}
			else if (rhs.get_dim() == 4 && dim == 4) {
				return nd_box{ dims[0] + rhs.dims[0], dims[1] + rhs.dims[1],
					dims[2] + rhs.dims[2], dims[3] + rhs.dims[3] };
			}
			else {
				return nd_box();
			}
		}
	};

	// Normalized intersection of boxes
	nd_box operator&(const nd_box &rhs) const {
		if (rhs.is_empty()) {
			return nd_box();
		}
		else {
			assert(rhs.get_dim() == dim);
			if (rhs.get_dim() == 1 && dim == 1) {
				return nd_box{ dims[0] & rhs.dims[0] };
			}
			else if (rhs.get_dim() == 2 && dim == 2) {
				return nd_box{ dims[0] & rhs.dims[0], dims[1] & rhs.dims[1] };
			}
			else if (rhs.get_dim() == 3 && dim == 3) {
				return nd_box{ dims[0] & rhs.dims[0], dims[1] & rhs.dims[1],
					dims[2] & rhs.dims[2] };
			}
			else if (rhs.get_dim() == 4 && dim == 4) {
				return nd_box{ dims[0] & rhs.dims[0], dims[1] & rhs.dims[1],
					dims[2] & rhs.dims[2], dims[3] & rhs.dims[3] };
			}
			else {
				return nd_box();
			}
		}

	};


	/*WHY TWO DIFFERENT METHODS FOR []? Because you can use it two different ways
	you can do...
	int x[5]; // this makes an array of 5. i.e [ num1, num2, num3, num4, num5]

	method 1: // makes num1 = 5;
	x[0] = 5;

	method 2; // makes y = num1 = 5;
	int y = x[0];*/
	// Returns reference to i-th range
	const range& operator[](int i) const {
		if (i > dim) {
			throw std::range_error("index out of bounds");
		}
		return dims[i];
	};

	// Returns reference to i-th range
	range& operator[](int i) {
		switch (i) {
		case 0:
			return dims[i];
		case 1:
			return dims[i];
		case 2:
			return dims[i];
		case 3:
			return dims[i];
		case 4:
			return dims[i];
		default:
			throw std::range_error("index out of bounds");
		}
	};
};

void test_range_methods(const range &r1, const range &r2) {
	std::cout << std::string(30, '*') << "\n"
		<< " r1 = " << r1 << "\n"
		<< " r2 = " << r2 << "\n"
		<< " r2 & r1 = " << (r2 & r1) << "\n"
		<< " r2 + r1 = " << (r2 + r1) << "\n";
}

void test_box_methods(const nd_box &b1, const nd_box &b2) {
	std::cout << std::string(30, '*') << "\n"
		<< " b1 = " << b1 << "\n"
		<< " b2 = " << b2 << "\n"
		<< " b2 & b1 = " << (b2 & b1) << "\n"
		<< " b2 + b1 = " << (b2 + b1) << "\n";
}

int main() {
	int number_of_cases = 0;
	std::cin >> number_of_cases;

	for (int i = 0; i < number_of_cases; ++i) {
		std::cout << "Case " << i << ":\n";
		int input_quantity = 0;
		std::cin >> input_quantity;
		std::vector<double> input_min(input_quantity), input_max(input_quantity);
		std::vector<range> range_inputs(input_quantity);

		for (int j = 0; j < input_quantity; ++j) {
			std::cin >> input_min[j] >> input_max[j];
			if (j == 0 || j % 2) {
				range_inputs[j] = range(input_min[j], input_max[j]);
			}
			else {
				range_inputs[j] = range(input_min[j], input_max[j]);
			}
		}

		test_range_methods(range_inputs[0], range_inputs[1]);

		if (input_quantity == 0) {
			test_box_methods(nd_box(), nd_box());
		}
		else if (input_quantity == 2) { //1D box
			test_box_methods(nd_box(range_inputs[0]), nd_box(range_inputs[1]));
		}
		else if (input_quantity == 4) { //2D box (rectangle)
			test_box_methods(nd_box(range_inputs[0], range_inputs[1]), nd_box(range_inputs[2], range_inputs[3]));
		}
		else if (input_quantity == 6) { //3D box
			test_box_methods(nd_box(range_inputs[0], range_inputs[1], range_inputs[2]),
				nd_box(range_inputs[3], range_inputs[4], range_inputs[5]));
		}
		else if (input_quantity == 8) { //4D box
			test_box_methods(nd_box(range_inputs[0], range_inputs[1], range_inputs[2], range_inputs[3]),
				nd_box(range_inputs[4], range_inputs[5], range_inputs[6], range_inputs[7]));
		}
	}
	return 0;
}