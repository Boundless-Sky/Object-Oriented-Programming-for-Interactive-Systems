#pragma once
#include "statistic.h"
#include <iostream>
#include <limits>
#include <algorithm>
#include <random>

class Average : public Statistic {
	double average;
	size_t count;
public:
	Average();
	void accumulate(double x) override;
	void postprocess() override;
	double result() const override;
	void print(std::ostream &os) const override;
};

