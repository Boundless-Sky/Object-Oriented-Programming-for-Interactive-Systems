/* Justin Ngo
Programming for engineers
9/29/2016
Homework 4: Problem 3 - Parsing Integers

Info: basically takes a number as a string data type
and checks if it is a number then print it*/
#include <iostream>
#include <cctype>
#include <string>

bool parse_int(const char *str, int &val) {
	size_t length = std::strlen(str);
	bool positive = true;
	bool startbit = false;
	for (size_t i = 0; i < length; i++) {
		if (isdigit(str[i]) || (str[0] == '+') || (str[0] == '-')) { //checks to see if the first is a positive or negative or the first and the rest is a number
			bool check_startbit = true;
			if (check_startbit == true) {
				check_startbit = false;
				if (str[0] == '-') {
					positive = false;
					startbit = true;
				}
				else if (str[0] == '+') {
					startbit = true;
				}
			}
		}
		else {
			return false;
		}
	}
	if (startbit) { //if the starting char is an identifier
		for (size_t i = 1; i < length; i++) {
			if (positive) { //if positive identifier
				val = (val * 10) + (str[i] - '0');
			}
			else { //if negative identifier
				val = (val * 10) + (str[i] - '0');
			}
		}
	}
	else {
		for (size_t i = 0; i < length; i++) {
			val = (val * 10) + (str[i] - '0');
		}
	}
	if (!positive) {
		val = -val;
	}
	return true;
}

int main() {
	int number_of_cases;
	std::cin >> number_of_cases;
	std::string input;
	int out_parameter = 0;
	for (int i = 0; i < number_of_cases; i++) {
		std::cout << "Case " << i << ":\n";
		std::cin >> input;
		if (parse_int(input.data(), out_parameter)) {
			std::cout << out_parameter << std::endl;
			out_parameter = 0;
		}
		else {
			std::cout << "Parsing failed" << std::endl;
		}
	}
	return 0;
}