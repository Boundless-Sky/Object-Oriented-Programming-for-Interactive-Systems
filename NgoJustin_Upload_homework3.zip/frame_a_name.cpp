/*Justin Ngo
September 16, 2016
ME EN 5250: Programming for Engineers
Homework 3: Problem 4 - frame the string

Info: input of the name (even with spaces)
then print a welcoming message*/


#include <iostream>
#include <string>
#include <limits>

void frame_that(std::string user_name) {
	std::string add_hello;
	add_hello = "* Hello, " + user_name + " *";
	int hello_line_length = (int)add_hello.size();

	std::string welcome;
	welcome = "* Welcome to my program";

	//check to see if the welcome wording is bigger or smaller than
	//the hello with the name
	if ((int)welcome.size() + 2 > hello_line_length) { //frames according to the welcome greeting
		for (int i = 0; i < (int)welcome.size() + 2; i++) {// creates the top layer of *
			std::cout << '*';
		}
		std::cout << '\n';
		// creates *    * with varying sizes
		std::string framing_asterisk(welcome.size() + 2, ' ');
		framing_asterisk.back() = '*';
		framing_asterisk.front() = '*';
		std::cout << framing_asterisk << std::endl;
		//modifies the hello statement to fit with the welcome greeting
		std::string hello_spaces((welcome.size() + 2 - hello_line_length), ' ');
		std::string modified_hello;
		modified_hello = "* Hello, " + user_name + hello_spaces + " *";
		std::cout << modified_hello << std::endl;
		//comepletes the greetings
		std::cout << welcome << " *\n";
		std::cout << framing_asterisk << std::endl; 

		for (int i = 0; i < (int)welcome.size() + 2; i++) {// creates bottom layer of *
			std::cout << '*';
		}
		std::cout << std::endl;
	} 
	else {
		for (int i = 0; i < hello_line_length; i++) {
			std::cout << '*';
		}
		std::cout << '\n';
		std::string framing_asterisk(hello_line_length, ' ');
		framing_asterisk.back() = '*';
		framing_asterisk.front() = '*';
		std::cout << framing_asterisk << std::endl;
		std::cout << add_hello << std::endl;

		//modifies the welcome statement to fit the longer hello statement
		std::string welcome_spaces(hello_line_length - welcome.size() - 1, ' ');
		std::string modified_welcome;
		modified_welcome = "* Welcome to my program" + welcome_spaces + "*";
		std::cout << modified_welcome << "\n";

		std::cout << framing_asterisk << std::endl;
		for (int i = 0; i < hello_line_length; i++) {
			std::cout << '*';
		}
		std::cout << std::endl;
	}
}


int main() {
	int number_of_cases;
	std::cin >> number_of_cases;
	std::string user_name;
	std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

	for (int i = 0; i < number_of_cases; i++) {
		std::cout << "Case " << i << ":\n";
		std::getline (std::cin, user_name);
		frame_that(user_name);
	}

	return 0;
}//end main