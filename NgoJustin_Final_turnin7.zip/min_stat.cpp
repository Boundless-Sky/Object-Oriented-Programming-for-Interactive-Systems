#include <iostream>
#include <limits>
#include <algorithm>
#include <random>
#include "statistic.h"
#include "min_stat.h"


Min::Min() {
	min = std::numeric_limits<double>::infinity();
}

void Min::accumulate(double x) {
	min = std::min(min, x);
}

void Min::postprocess() {
	// Nothing to do
}

double Min::result() const {
	return min;
}

void Min::print(std::ostream &os) const {
	os << "Min = " << min;
}
