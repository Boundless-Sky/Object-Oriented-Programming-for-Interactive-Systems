/*Justin Ngo
Programming for Engineers: Homework 5
October 22, 2016
Label Generator: User inputs prefix string i.e figure in figure 1. 
				 then it just increments > figure 2 > figure 3... etc. 

				 input: number of cases 
						Prefix (i.e. Fig, figure_1, P ... etc)
						start numbering from...     end numbering...
*/

#include <iostream>
#include <string>

class LabelGenerator {
	std::string signature;
	int value;

public:
	//This is an added constructor with the ": signature(prefix), value(start) {}"
	// is an initialization list. Its pretty much the same thing below in CONSTRUCTOR DEFINITION
	LabelGenerator(const std::string &prefix, int start) : signature(prefix), value(start) {}; 												  
	LabelGenerator() {} //need the default constructor if you add one
	std::string next_label(); //This is a method
};

//This is the method definition. 
std::string LabelGenerator::next_label() {
	std::string label = signature + std::to_string(value);
	value++;
	return label;
}

//CONSTRUCTOR DEFINITION can be placed in a separate cpp file and called like a header
//i.e. #include "LabelGenerator.cpp". Or whatever I the file is named as. 
//LabelGenerator::LabelGenerator(const std::string &prefix, int start) {
// signature = prefix; value = start;
//}

int main() {
	int number_of_cases;
	std::cin >> number_of_cases;
	for (int i = 0; i < number_of_cases; i++) {
		std::cout << "Case " << i << ":" << std::endl;
		std::string prefix;
		int start;
		int end;
		//need the ignore because the stream already contains a /n when you enter the number of cases. 
		std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
		std::getline(std::cin, prefix);
		std::cin >> start;
		std::cin >> end;
		LabelGenerator labels(prefix, start);
		for (int j = start; j <= end; j++) {
			std::cout << labels.next_label() << " ";
		}
		std::cout << std::endl;
	}
	return 0;
}// end main
