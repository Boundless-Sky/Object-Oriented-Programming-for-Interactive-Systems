/*Justin Ngo
ME EN 5250: Programming for Engineers
Homework 6 - rational
In this problem you will implement a class that works as an abstraction for
rational numbers. Recall that rational numbers are numbers of the form a/b
where a and b are integers, and b doens't = 0

NOTE:: ASSUME b is never 0;
*/

#include <iostream>

//Euclidean algorithm
int GCD(int a, int b){
	while (b != 0) {
		int temp = b;
		b = a % b;
		a = temp;
	}
	return a;
}

class Rational
{
public:
	Rational();
	Rational(int n, int d); //assume d is always non zero
	Rational(int n);
	int get_numerator() const;
	int get_denominator() const;
	void normalize();
	Rational operator+(Rational b) const;
	Rational operator-(Rational b) const;
	Rational operator*(Rational b) const;
	Rational operator/(Rational b) const;
	bool operator==(Rational b) const;
	bool operator<(Rational b) const;
	double toDecimal() const;

private:
	// much check as soon as
	// rational object is called
	// and maintain in each function
	// that denom > 0, and GCD(num, denom) == 1 (so normalize() it)
	int num;
	int denom;
};
Rational::Rational() : num(0), denom(0) {}
Rational::Rational(int n, int d) {
	num = n;
	denom = d;
	normalize();
}
Rational::Rational(int n) {
	num = n;
	denom = 1;
}
int Rational::get_numerator() const {
	return num;
}
int Rational::get_denominator() const {
	return denom;
}
void Rational::normalize() {
	while (GCD(num, denom) != 1) {
		int greatest_divsor = GCD(num, denom);
		num = num / greatest_divsor;
		denom = denom / greatest_divsor;
	}
	if (denom < 0) {
		denom = -denom;
		num = -num;
	}
}

Rational Rational::operator+(Rational b) const {
	int n = this->get_numerator();
	int d = this->get_denominator();
	if (this->get_denominator() != b.get_denominator()) {
		//cross multiply
		n = n*b.get_denominator();
		b.num = b.num*d;
		d = d*b.get_denominator();
		b.denom = b.denom*d;
		//add
		n = n + b.num;
		return Rational{ n, d };
	}
	else {
		n = n + b.num;
		return Rational{ n, d };
	}
}
Rational Rational::operator-(Rational b) const {
	int n = this->get_numerator();
	int d = this->get_denominator();
	if (this->get_denominator() != b.get_denominator()) {
		//cross multiply
		n = n*b.get_denominator();
		b.num = b.num*d;
		d = d*b.get_denominator();
		b.denom = b.denom*d;
		//add
		n = n - b.num;
		return Rational{ n, d };
	}
	else {
		n = n - b.num;
		return Rational{ n, d };
	}
}
Rational Rational::operator*(Rational b) const {
	return Rational{ this->get_numerator() * b.get_numerator(), this->get_denominator() * b.get_denominator() };
}
Rational Rational::operator/(Rational b) const {
	return Rational{ this->get_numerator() * b.get_denominator(), this->get_denominator() * b.get_numerator() };
}
bool Rational::operator==(Rational b) const {
	if ((this->get_numerator() == b.get_numerator()) && (this->get_denominator() == b.get_denominator())) {
		return true;
	}
	else {
		return false;
	}
}
bool Rational::operator<(Rational b) const {
	if (this->toDecimal() < b.toDecimal()){
		return true;
	}
	else {
		return false;
	}
}
double Rational::toDecimal() const {
	return this->get_numerator() / ((double)this->get_denominator());
}


std::ostream& operator<<(std::ostream& output, Rational a) {
	output << a.get_numerator() << "/" << a.get_denominator();
	return output;
}


int main() {
	int number_of_cases = 0;
	std::cin >> number_of_cases;
	for (int i = 0; i < number_of_cases; ++i) {
		std::cout << "Case " << i << ":\n";
		int a, b, c, d;
		Rational A, B;
		std::cin >> a >> b >> c >> d;
		if (a % b == 0) {
			a = a / b;
			A = Rational{ a };
		}
		else {
			A = Rational { a, b };
		}
		if (c % d == 0) {
			c = c / d;
			B = Rational{ c };
		}
		else {
			B = Rational{ c, d };
		}
		std::cout << A + B << " " << A - B << " " << A * B << " " << A / B << " ";
		if (A < B) {
			std::cout << "true" << std::endl;;
		}
		else {
			std::cout << "false" << std::endl;
		}
		std::cout << A.toDecimal() << " " << B.toDecimal() << std::endl;
	}
	return 0;
}
